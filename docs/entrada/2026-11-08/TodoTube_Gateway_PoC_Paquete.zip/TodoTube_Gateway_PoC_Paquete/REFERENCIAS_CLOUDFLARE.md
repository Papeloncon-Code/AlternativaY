# Referencias técnicas oficiales

Fuentes oficiales de Cloudflare consultadas el 7 de noviembre de 2026. El agente debe verificar su vigencia y los límites del plan activo al implementar.

1. **Streams API:** https://developers.cloudflare.com/workers/runtime-apis/streams/  
   Describe `ReadableStream`, `TransformStream` y el envío de respuestas progresivas sin materializar todo el cuerpo en memoria. La documentación consultada señala límite de memoria de 128 MB para Workers.
2. **Workers Limits:** https://developers.cloudflare.com/workers/platform/limits/  
   Límites por plan, CPU, subrequests, conexiones salientes, memoria y request/response. La página consultada mostraba actualización de octubre de 2026; los valores pueden cambiar.
3. **Best Practices:** https://developers.cloudflare.com/workers/best-practices/workers-best-practices/  
   Recomienda streaming de cuerpos grandes y evitar `response.text()` / `arrayBuffer()` para cargas grandes.
4. **Response API:** https://developers.cloudflare.com/workers/runtime-apis/response/  
   Semántica de `Response`, cuerpo `ReadableStream`, cabeceras y `Content-Length`.
5. **Pricing:** https://developers.cloudflare.com/workers/platform/pricing/  
   Revisar solicitudes, CPU y cargos del plan. No deducir el coste total del servicio solo a partir del precio de invocación.
6. **Piped Proxy:** https://github.com/TeamPiped/piped-proxy  
   Proyecto de referencia para estudiar una arquitectura de proxy multimedia. No es evidencia de compatibilidad de YouTube con Cloudflare Workers ni autorización para reutilizar su código sin revisar licencia.

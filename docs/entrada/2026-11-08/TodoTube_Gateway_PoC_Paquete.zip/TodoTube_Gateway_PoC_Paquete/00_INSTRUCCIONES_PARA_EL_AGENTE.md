# Instrucciones para el agente de código — TodoTube: PoC de gateway multimedia sin extensión

**Repositorio:** `Papeloncon-Code/AlternativaY`  
**Rama de trabajo de referencia:** `sdd/investigacion-y-especificacion`  
**Objetivo:** estudiar e implementar una prueba de concepto aislada de un segundo Cloudflare Worker para transporte multimedia, conservando el reproductor HTML5 + Shaka existente.  
**No desplegar ni alterar producción.**

## Qué debe hacer el agente

Trabaja directamente en el repositorio conectado. Primero incorpora los cuatro documentos incluidos en este paquete a las rutas indicadas en la sección «Archivos que debes incorporar». Después audita el código actual e implementa la PoC, ejecuta las pruebas y deja un informe de resultados. Trabaja en una rama nueva, no en la rama de referencia ni en `main`.

No te limites a copiar los documentos: debes implementar la PoC descrita y ejecutar las pruebas. No afirmes que TodoTube ya funciona sin Puente hasta que exista una prueba específica de reproducción real con el flujo objetivo y evidencia reproducible.

## Contexto verificado del repositorio

En la rama de referencia se verificó lo siguiente:

- `apps/web/src/components/PlayerHost.tsx` escoge `OwnPlayer` solo cuando `useBridge()` devuelve un puente disponible y la sesión no está en fallback; de lo contrario monta `OfficialPlayer`.
- `apps/web/src/player/TodoTubePlayer.ts` utiliza Shaka, `youtubei.js/web`, `SabrStreamingAdapter`, `buildSabrFormat` y BotGuard. Su método `available()` también exige `checkExtension()`.
- `apps/web/src/player/ShakaPlayerAdapter.ts` realiza `fetch(uri, init)` desde el navegador y procesa las respuestas `application/vnd.yt-ump` con `SabrUmpProcessor`.
- El Worker web actual está configurado en `apps/web/wrangler.toml` (`name = "todotube"`, `main = "worker.js"`). No lo reutilices ni cambies sus rutas para esta PoC.
- `apps/web/package.json` contiene scripts de build y Playwright. Debes inspeccionar los scripts reales antes de decidir cómo ejecutar la regresión.
- `docs/adr/ADR-005-cliente-youtube-completo.md` establece explícitamente que la extracción de YouTube se ejecuta en el dispositivo del usuario, nunca en servidores propios.

Este contexto es una fotografía de la rama de referencia; vuelve a leer los archivos al iniciar porque el repositorio puede haber cambiado.

## Restricción arquitectónica que no puedes saltarte

El gateway de esta tarea **NO debe recibir, resolver ni retransmitir vídeos reales de YouTube o Googlevideo**. ADR-005 sigue vigente. Esta tarea demuestra primero que Cloudflare Worker puede transportar un vídeo de prueba propio con `GET`, `HEAD`, `Range`, `206`, CORS y streaming.

Si para conectar el gateway a YouTube se requiere trasladar la extracción, la obtención de tokens, la llamada a InnerTube/BotGuard o la descarga de segmentos de YouTube al servidor, detente en ese punto. No cambies ADR-005 por tu cuenta. Deja explicado qué decisión del propietario falta y qué evidencia técnica sería necesaria para una ADR posterior.

## Secuencia obligatoria

1. **Auditoría inicial:** inspecciona estructura, ramas, estado Git, convenciones, Workers existentes, pruebas, dependencias y configuración. No sobrescribas cambios ajenos.
2. **Crear rama:** crea una rama de feature desde la rama de referencia actual. No trabajes directamente en la rama de referencia ni en `main`.
3. **Incorporar documentos:** añade los cuatro archivos del paquete a las rutas exactas que se indican más abajo. Actualiza el índice/README de documentación solo si existe una convención clara y el cambio es pertinente.
4. **Diseñar el Worker separado:** usa un proyecto independiente, por ejemplo `apps/media-gateway/` o la ruta coherente con el monorepo. No edites `apps/web/wrangler.toml`.
5. **Implementar el origen de prueba:** usa un fixture de vídeo de propiedad del proyecto o un servidor de prueba local. No descargues un vídeo de YouTube para usarlo como fixture. No presupongas que R2 está disponible; úsalo únicamente si ya existe y el coste/permiso está verificado.
6. **Implementar el transporte:** streaming por `ReadableStream`, soporte correcto para `GET`, `HEAD`, `Range`, `206`, `416`, CORS limitado y cancelación cuando el runtime lo permita. No almacenes el archivo completo en memoria.
7. **Aislamiento y seguridad:** el destino upstream debe ser fijo y allowlisted. No aceptes URLs arbitrarias enviadas por el cliente. Bloquea SSRF, IP privadas, loopback, link-local, endpoints de metadatos, traversal y redirecciones a hosts ajenos.
8. **Cliente de prueba:** crea una página experimental independiente que reproduzca el fixture mediante `<video>` y, si es viable, Shaka. No cambies `PlayerHost`, `OwnPlayer`, `OfficialPlayer`, `TodoTubePlayer` ni `ShakaPlayerAdapter` en esta fase.
9. **Pruebas:** implementa y ejecuta los casos de `test-plan.md`. Incluye pruebas unitarias, integración local y una verificación manual en navegador si el entorno lo permite.
10. **Regresión:** ejecuta build, typecheck y suite existente. No debilites pruebas para hacerlas pasar.
11. **Informe:** crea `specs/008-gateway-multimedia/results.md` con comandos, evidencia, matriz de aceptación, fallos, elementos bloqueados y recomendación.
12. **Entrega:** commit en la rama de feature y abre un PR en estado draft si la integración GitHub lo permite. No hagas merge ni deploy.

## Archivos que debes incorporar

Copia exactamente los siguientes archivos incluidos en este paquete:

| Archivo de este paquete | Ruta destino en el repositorio |
|---|---|
| `docs/adr/ADR-009-gateway-multimedia-sin-puente.md` | `docs/adr/ADR-009-gateway-multimedia-sin-puente.md` |
| `specs/008-gateway-multimedia/spec.md` | `specs/008-gateway-multimedia/spec.md` |
| `specs/008-gateway-multimedia/implementation-plan.md` | `specs/008-gateway-multimedia/implementation-plan.md` |
| `specs/008-gateway-multimedia/test-plan.md` | `specs/008-gateway-multimedia/test-plan.md` |

## Criterios de cierre

La tarea solo se considera completada cuando:

- Los documentos están en la rama de feature.
- Existe un Worker experimental separado del Worker web.
- El Worker solo accede a un fixture de prueba permitido.
- `GET`, `HEAD`, `Range`, `206`, `416`, CORS y streaming tienen evidencia de pruebas.
- El cliente de prueba reproduce y permite seek en el fixture.
- Las pruebas de seguridad y regresión se ejecutaron y reportaron.
- No hay cambios en el flujo de YouTube, Puente, fallback ni despliegue de producción.
- El informe distingue claramente **aprobado**, **fallido**, **bloqueado** y **no ejecutado**.

**No marques como resuelto «TodoTube funciona sin Puente».** Esta PoC valida el gateway con un origen controlado; no prueba que YouTube funcione a través de él ni autoriza mover la extracción a servidores.

## Referencias oficiales que debes volver a consultar

Consulta la documentación vigente al implementar; no te bases solo en esta lista:

- Cloudflare Workers Streams API: https://developers.cloudflare.com/workers/runtime-apis/streams/
- Cloudflare Workers Limits: https://developers.cloudflare.com/workers/platform/limits/
- Cloudflare Workers Best Practices: https://developers.cloudflare.com/workers/best-practices/workers-best-practices/
- Cloudflare Workers Response API: https://developers.cloudflare.com/workers/runtime-apis/response/
- Cloudflare Workers Pricing: https://developers.cloudflare.com/workers/platform/pricing/
- Piped Proxy (referencia de arquitectura; no copiar sin revisar licencia y alcance): https://github.com/TeamPiped/piped-proxy

La documentación consultada el 7 de noviembre de 2026 describe streaming por Streams API y un límite de memoria de 128 MB. No asumas que streaming significa coste cero, ancho de banda ilimitado o que cualquier protocolo de YouTube será compatible.

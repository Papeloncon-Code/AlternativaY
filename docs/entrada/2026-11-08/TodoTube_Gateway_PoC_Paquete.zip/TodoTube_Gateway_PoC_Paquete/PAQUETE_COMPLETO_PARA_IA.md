# Instrucciones para el agente de código — TodoTube: PoC de gateway multimedia sin extensión

**Repositorio:** `Papeloncon-Code/AlternativaY`  
**Rama de trabajo de referencia:** `sdd/investigacion-y-especificacion`  
**Objetivo:** estudiar e implementar una prueba de concepto aislada de un segundo Cloudflare Worker para transporte multimedia, conservando el reproductor HTML5 + Shaka existente.  
**No desplegar ni alterar producción.**

## Qué debe hacer el agente

Trabaja directamente en el repositorio conectado. Primero incorpora los cuatro documentos incluidos en este paquete a las rutas indicadas en la sección «Archivos que debes incorporar». Después audita el código actual e implementa la PoC, ejecuta las pruebas y deja un informe de resultados. Trabaja en una rama nueva, no en la rama de referencia ni en `main`.

No te limites a copiar los documentos: debes implementar la PoC descrita y ejecutar las pruebas. No afirmes que TodoTube ya funciona sin Puente hasta que exista una prueba específica de reproducción real con el flujo objetivo y evidencia reproducible.

## Contexto verificado del repositorio

En la rama de referencia se verificó lo siguiente:

- `apps/web/src/components/PlayerHost.tsx` escoge `OwnPlayer` solo cuando `useBridge()` devuelve un puente disponible y la sesión no está en fallback; de lo contrario monta `OfficialPlayer`.
- `apps/web/src/player/TodoTubePlayer.ts` utiliza Shaka, `youtubei.js/web`, `SabrStreamingAdapter`, `buildSabrFormat` y BotGuard. Su método `available()` también exige `checkExtension()`.
- `apps/web/src/player/ShakaPlayerAdapter.ts` realiza `fetch(uri, init)` desde el navegador y procesa las respuestas `application/vnd.yt-ump` con `SabrUmpProcessor`.
- El Worker web actual está configurado en `apps/web/wrangler.toml` (`name = "todotube"`, `main = "worker.js"`). No lo reutilices ni cambies sus rutas para esta PoC.
- `apps/web/package.json` contiene scripts de build y Playwright. Debes inspeccionar los scripts reales antes de decidir cómo ejecutar la regresión.
- `docs/adr/ADR-005-cliente-youtube-completo.md` establece explícitamente que la extracción de YouTube se ejecuta en el dispositivo del usuario, nunca en servidores propios.

Este contexto es una fotografía de la rama de referencia; vuelve a leer los archivos al iniciar porque el repositorio puede haber cambiado.

## Restricción arquitectónica que no puedes saltarte

El gateway de esta tarea **NO debe recibir, resolver ni retransmitir vídeos reales de YouTube o Googlevideo**. ADR-005 sigue vigente. Esta tarea demuestra primero que Cloudflare Worker puede transportar un vídeo de prueba propio con `GET`, `HEAD`, `Range`, `206`, CORS y streaming.

Si para conectar el gateway a YouTube se requiere trasladar la extracción, la obtención de tokens, la llamada a InnerTube/BotGuard o la descarga de segmentos de YouTube al servidor, detente en ese punto. No cambies ADR-005 por tu cuenta. Deja explicado qué decisión del propietario falta y qué evidencia técnica sería necesaria para una ADR posterior.

## Secuencia obligatoria

1. **Auditoría inicial:** inspecciona estructura, ramas, estado Git, convenciones, Workers existentes, pruebas, dependencias y configuración. No sobrescribas cambios ajenos.
2. **Crear rama:** crea una rama de feature desde la rama de referencia actual. No trabajes directamente en la rama de referencia ni en `main`.
3. **Incorporar documentos:** añade los cuatro archivos del paquete a las rutas exactas que se indican más abajo. Actualiza el índice/README de documentación solo si existe una convención clara y el cambio es pertinente.
4. **Diseñar el Worker separado:** usa un proyecto independiente, por ejemplo `apps/media-gateway/` o la ruta coherente con el monorepo. No edites `apps/web/wrangler.toml`.
5. **Implementar el origen de prueba:** usa un fixture de vídeo de propiedad del proyecto o un servidor de prueba local. No descargues un vídeo de YouTube para usarlo como fixture. No presupongas que R2 está disponible; úsalo únicamente si ya existe y el coste/permiso está verificado.
6. **Implementar el transporte:** streaming por `ReadableStream`, soporte correcto para `GET`, `HEAD`, `Range`, `206`, `416`, CORS limitado y cancelación cuando el runtime lo permita. No almacenes el archivo completo en memoria.
7. **Aislamiento y seguridad:** el destino upstream debe ser fijo y allowlisted. No aceptes URLs arbitrarias enviadas por el cliente. Bloquea SSRF, IP privadas, loopback, link-local, endpoints de metadatos, traversal y redirecciones a hosts ajenos.
8. **Cliente de prueba:** crea una página experimental independiente que reproduzca el fixture mediante `<video>` y, si es viable, Shaka. No cambies `PlayerHost`, `OwnPlayer`, `OfficialPlayer`, `TodoTubePlayer` ni `ShakaPlayerAdapter` en esta fase.
9. **Pruebas:** implementa y ejecuta los casos de `test-plan.md`. Incluye pruebas unitarias, integración local y una verificación manual en navegador si el entorno lo permite.
10. **Regresión:** ejecuta build, typecheck y suite existente. No debilites pruebas para hacerlas pasar.
11. **Informe:** crea `specs/008-gateway-multimedia/results.md` con comandos, evidencia, matriz de aceptación, fallos, elementos bloqueados y recomendación.
12. **Entrega:** commit en la rama de feature y abre un PR en estado draft si la integración GitHub lo permite. No hagas merge ni deploy.

## Archivos que debes incorporar

Copia exactamente los siguientes archivos incluidos en este paquete:

| Archivo de este paquete | Ruta destino en el repositorio |
|---|---|
| `docs/adr/ADR-009-gateway-multimedia-sin-puente.md` | `docs/adr/ADR-009-gateway-multimedia-sin-puente.md` |
| `specs/008-gateway-multimedia/spec.md` | `specs/008-gateway-multimedia/spec.md` |
| `specs/008-gateway-multimedia/implementation-plan.md` | `specs/008-gateway-multimedia/implementation-plan.md` |
| `specs/008-gateway-multimedia/test-plan.md` | `specs/008-gateway-multimedia/test-plan.md` |

## Criterios de cierre

La tarea solo se considera completada cuando:

- Los documentos están en la rama de feature.
- Existe un Worker experimental separado del Worker web.
- El Worker solo accede a un fixture de prueba permitido.
- `GET`, `HEAD`, `Range`, `206`, `416`, CORS y streaming tienen evidencia de pruebas.
- El cliente de prueba reproduce y permite seek en el fixture.
- Las pruebas de seguridad y regresión se ejecutaron y reportaron.
- No hay cambios en el flujo de YouTube, Puente, fallback ni despliegue de producción.
- El informe distingue claramente **aprobado**, **fallido**, **bloqueado** y **no ejecutado**.

**No marques como resuelto «TodoTube funciona sin Puente».** Esta PoC valida el gateway con un origen controlado; no prueba que YouTube funcione a través de él ni autoriza mover la extracción a servidores.

## Referencias oficiales que debes volver a consultar

Consulta la documentación vigente al implementar; no te bases solo en esta lista:

- Cloudflare Workers Streams API: https://developers.cloudflare.com/workers/runtime-apis/streams/
- Cloudflare Workers Limits: https://developers.cloudflare.com/workers/platform/limits/
- Cloudflare Workers Best Practices: https://developers.cloudflare.com/workers/best-practices/workers-best-practices/
- Cloudflare Workers Response API: https://developers.cloudflare.com/workers/runtime-apis/response/
- Cloudflare Workers Pricing: https://developers.cloudflare.com/workers/platform/pricing/
- Piped Proxy (referencia de arquitectura; no copiar sin revisar licencia y alcance): https://github.com/TeamPiped/piped-proxy

La documentación consultada el 7 de noviembre de 2026 describe streaming por Streams API y un límite de memoria de 128 MB. No asumas que streaming significa coste cero, ancho de banda ilimitado o que cualquier protocolo de YouTube será compatible.


---

# ADR-009 · Gateway multimedia web sin extensión

- **Estado:** Propuesto; autoriza únicamente una prueba de concepto aislada.
- **Fecha:** 2026-11-07
- **Relacionado con:** ADR-005, ADR-007, Spike T-100, `apps/web/src/player/TodoTubePlayer.ts`, `apps/web/src/player/ShakaPlayerAdapter.ts`, `apps/web/src/components/PlayerHost.tsx`.

## Contexto

La versión web actual necesita TodoTube Puente para utilizar el reproductor propio. La inspección del código confirma:

1. `PlayerHost.tsx` selecciona `OwnPlayer` solamente cuando `useBridge()` está disponible y la sesión no está en fallback. En caso contrario selecciona `OfficialPlayer`.
2. `TodoTubePlayer.available()` exige `checkExtension()` además de soporte del navegador para Shaka.
3. `ShakaPlayerAdapter.ts` ejecuta `fetch(uri, init)` desde el navegador para las solicitudes multimedia. En respuestas UMP procesa el cuerpo como stream y utiliza `SabrUmpProcessor`.
4. El Puente modifica cabeceras y reglas de red; no retransmite actualmente todos los segmentos multimedia a través de un servidor de TodoTube.

Por tanto, el reproductor propio y el transporte multimedia son responsabilidades distintas. Sustituir los controles visuales no elimina CORS ni la dependencia del Puente.

## Decisión propuesta

Construir una prueba de concepto de un **segundo Cloudflare Worker**, separado del Worker que sirve TodoTube Web. La PoC utilizará exclusivamente un origen multimedia de prueba controlado por el proyecto y archivos de vídeo de prueba propios.

La PoC debe demostrar si un Worker puede entregar contenido multimedia en streaming con las semánticas HTTP necesarias para Shaka: solicitudes GET/HEAD, Range, respuestas 206, cancelación, cabeceras CORS y flujo por chunks.

## Restricción obligatoria: ADR-005 sigue vigente

ADR-005 establece que la extracción de YouTube se ejecuta en el dispositivo del usuario y nunca en nuestros servidores. Este ADR-009 **no revoca ni modifica ADR-005**.

En esta fase queda prohibido:

- Enviar URLs de reproducción de YouTube/Googlevideo al Worker.
- Hacer que el Worker consulte InnerTube, YouTube.js, BotGuard o PoToken.
- Hacer que el Worker obtenga, descifre, transforme o retransmita segmentos reales de YouTube.
- Cambiar la versión de producción para que use el gateway.
- Desplegar el Worker o cambiar DNS/rutas de producción.

Para probar el transporte se usará un fixture local/propio. Una futura integración con streams de YouTube requerirá una decisión explícita del propietario que revise ADR-005, riesgos contractuales, seguridad, viabilidad técnica y costes. No asumir que un proxy de medios es compatible con ADR-005.

## Alternativas

| Alternativa | Ventaja | Coste o limitación |
|---|---|---|
| Puente MV3 actual | El navegador descarga directamente; no se paga ancho de banda de retransmisión | Requiere instalar extensión |
| Gateway Worker | No exige extensión al usuario; permite controlar CORS y Range desde un origen propio | Todo el tráfico retransmitido consume recursos/egress y añade un salto; compatibilidad con YouTube no demostrada |
| IFrame oficial | Sin extensión ni gateway | No ofrece la interfaz propia de la variante `full` |

## Consecuencias esperadas

- La interfaz web y el reproductor Shaka deben permanecer desacoplados del origen de los bytes.
- La PoC no puede cambiar el comportamiento de producción.
- Deben medirse latencia, streaming real, cancelación, consumo y límites de Cloudflare.
- La PoC no demuestra que YouTube acepte solicitudes desde Workers ni que SABR/BotGuard puedan trasladarse allí.

## Criterio para reconsiderar ADR-005

Solo abrir una nueva decisión si la PoC con fixtures pasa sus pruebas y existe un análisis separado que responda: qué datos se obtienen en el dispositivo, qué datos pasan por el gateway, desde qué IP se solicitan, qué tokens/cookies se usan, qué condiciones contractuales aplican, qué coste tiene y qué límites de Cloudflare afectan. Hasta entonces, ADR-005 permanece aceptado y prevalece.


---

# Especificación 008 · PoC de gateway multimedia para la web

- **Estado:** Lista para implementación experimental; no autoriza producción.
- **Fecha:** 2026-11-07
- **Decisión relacionada:** [ADR-009](../../docs/adr/ADR-009-gateway-multimedia-sin-puente.md)
- **Decisión que se mantiene:** [ADR-005](../../docs/adr/ADR-005-cliente-youtube-completo.md)

## 1. Objetivo

Comprobar, con un origen de vídeo controlado por TodoTube, si un Cloudflare Worker independiente puede retransmitir multimedia en streaming y ser consumido por Shaka/HTML5 sin instalar TodoTube Puente.

La PoC debe producir evidencia reproducible. No debe intentar reproducir contenido de YouTube en el Worker.

## 2. Estado actual confirmado

- `apps/web/src/components/PlayerHost.tsx`: el reproductor propio se monta solo si existe bridge y no se activó fallback.
- `apps/web/src/player/TodoTubePlayer.ts`: usa Shaka, YouTube.js, BotGuard y `SabrStreamingAdapter`; `available()` exige `checkExtension()`.
- `apps/web/src/player/ShakaPlayerAdapter.ts`: Shaka hace `fetch(uri, init)` en el navegador; procesa respuestas UMP con `SabrUmpProcessor`.
- `apps/web/wrangler.toml`: configura el Worker web actual `todotube`. No reutilizar este Worker como gateway ni modificar su ruta de producción para esta PoC.
- `apps/web/package.json`: build actual ejecuta TypeScript, Vite y empaquetado del puente. No romper este flujo.

## 3. Alcance

### Incluido

1. Crear un Worker separado para el gateway experimental, siguiendo las convenciones reales del repositorio después de inspeccionarlas.
2. Configurar un origen de prueba controlado por el proyecto (fixture de vídeo pequeño, sin copyright de terceros).
3. Implementar proxy streaming limitado al origen de prueba, con:
   - GET y HEAD;
   - Range de bytes y respuesta 206;
   - Content-Range, Accept-Ranges, Content-Length y Content-Type cuando correspondan;
   - CORS explícito para el origen de desarrollo/prueba;
   - respuesta OPTIONS coherente;
   - propagación de cancelación del cliente al upstream cuando la plataforma lo permita;
   - propagación de errores y códigos HTTP sin convertir todos los errores en 200.
4. Pruebas automatizadas unitarias e integración del Worker.
5. Una página/fixture de prueba aislada que reproduzca el vídeo con HTML5 y, si el entorno permite, con Shaka.
6. Informe con resultados, límites, costes/mediciones disponibles y recomendación.

### Fuera de alcance

- Reproducir vídeos reales de YouTube a través del gateway.
- InnerTube, YouTube.js, BotGuard, PoToken, cookies de Google o descifrado de firmas en el Worker.
- Reemplazar o eliminar la extensión Puente.
- Cambiar `PlayerHost`, `OwnPlayer`, `OfficialPlayer` o el comportamiento de fallback en producción.
- Cambiar la interfaz/controles del reproductor.
- Desplegar Workers, configurar dominios, secretos, DNS o rutas de producción.
- Guardar en caché contenido multimedia de terceros.
- Abrir un proxy genérico que acepte URLs arbitrarias.

## 4. Requisitos funcionales

- **RF-01:** el Worker solo puede recuperar recursos desde un origen de prueba allowlisted y configurado por variable de entorno.
- **RF-02:** el cliente puede solicitar el archivo completo mediante GET.
- **RF-03:** el cliente puede solicitar un rango de bytes; si el origen responde correctamente, el Worker devuelve 206 y preserva Content-Range.
- **RF-04:** HEAD devuelve cabeceras equivalentes sin cuerpo.
- **RF-05:** el Worker retransmite el cuerpo mediante Streams API; no llama a `arrayBuffer()`, `text()` ni `blob()` para almacenar el archivo completo.
- **RF-06:** OPTIONS devuelve las cabeceras CORS necesarias únicamente para los orígenes permitidos.
- **RF-07:** el Worker rechaza métodos no soportados, destinos fuera de allowlist, rutas malformadas y redirecciones hacia hosts no permitidos.
- **RF-08:** cancelar la reproducción cancela la lectura upstream cuando sea técnicamente posible.
- **RF-09:** los errores upstream conservan un estado HTTP apropiado y se registran sin filtrar URLs sensibles ni tokens.
- **RF-10:** la PoC no modifica la ruta de reproducción de producción ni el comportamiento de Puente.

## 5. Requisitos de seguridad

- No aceptar una URL completa arbitraria desde query string o body.
- No permitir SSRF, acceso a IP privadas, localhost, metadata endpoints ni hosts no allowlisted.
- Validar método, path, origen y parámetros antes de hacer fetch.
- Desactivar credenciales/cookies por defecto.
- No aceptar ni registrar cookies, Authorization, PoToken o credenciales de Google.
- No seguir redirecciones a un host no permitido; validar cada destino o rechazar redirecciones.
- Limitar tamaño/rango, concurrencia y tiempo de solicitudes de acuerdo con límites documentados de Cloudflare.
- No exponer trazas, cabeceras internas ni secretos al cliente.
- Añadir límites básicos contra abuso; documentar qué controles requieren autenticación antes de cualquier uso público.
- No usar CORS como mecanismo de autenticación: CORS no impide que otros clientes HTTP llamen al endpoint.

## 6. Arquitectura objetivo de la PoC

```text
Browser (fixture de prueba)
  |
  | GET /media/test-video.mp4
  | Range: bytes=...
  v
Cloudflare Worker: todotube-media-gateway-dev
  |
  | fetch a origen fijo allowlisted
  v
Origen de fixture controlado por el proyecto
```

El Worker web actual permanece independiente. El gateway no recibe IDs de YouTube ni URLs de Googlevideo.

## 7. Criterios de aceptación

- **CA-01:** el Worker se ejecuta localmente con Wrangler sin modificar el Worker web existente.
- **CA-02:** un GET de fixture devuelve los mismos bytes y Content-Type que el origen.
- **CA-03:** Range válido devuelve 206, Content-Range correcto y bytes exactos.
- **CA-04:** Range no satisfacible devuelve 416 con la cabecera adecuada cuando corresponda.
- **CA-05:** HEAD no devuelve cuerpo.
- **CA-06:** OPTIONS responde con CORS limitado al origen permitido; origen no permitido no recibe autorización CORS.
- **CA-07:** destino arbitrario, localhost, IP privada, metadata endpoint y redirección a host no permitido son rechazados.
- **CA-08:** una prueba de streaming confirma que el Worker entrega chunks antes de que el fixture completo se haya consumido; no materializa el archivo entero en memoria.
- **CA-09:** cancelar la petición aborta upstream o documenta la limitación demostrada.
- **CA-10:** el fixture reproduce y permite seek con HTML5; probar Shaka si la integración aislada puede hacerse sin acoplar producción.
- **CA-11:** build, lint/typecheck y suite existente de la web continúan pasando.
- **CA-12:** no hay cambios de producción ni llamadas a YouTube/Googlevideo desde el Worker.
- **CA-13:** se entrega un informe que separa resultados verificados, no verificados y limitaciones del entorno.

## 8. Definición de terminado

La PoC está terminada cuando todos los criterios CA-01 a CA-13 tienen evidencia o una explicación explícita de bloqueo. Un test omitido no cuenta como aprobado. No se considera que la dependencia de Puente esté eliminada ni que YouTube funcione sin extensión por haber aprobado esta PoC.


---

# Plan de implementación para agente de código · Gateway multimedia PoC

**Lee primero:** `docs/adr/ADR-005-cliente-youtube-completo.md`, `docs/adr/ADR-009-gateway-multimedia-sin-puente.md`, `specs/006-spike-reproductor-propio/spec.md` y `specs/008-gateway-multimedia/spec.md`.

## Instrucción principal

Implementa una PoC aislada y comprobable de un Cloudflare Worker que retransmita un archivo de vídeo de prueba controlado por el proyecto. No intentes integrar YouTube ni quitar TodoTube Puente en esta tarea.

No afirmes que la web ya funciona sin extensión. No cambies producción. No despliegues.

## Fase 0 — Auditoría antes de editar

1. Inspecciona el árbol real del repositorio, package manager, workspaces, convenciones de tests, configuración Wrangler y scripts.
2. Comprueba si ya existe un Worker auxiliar, fixtures multimedia o utilidades de streaming que deban reutilizarse.
3. Relee los archivos actuales antes de modificarlos; no asumas que las rutas o fragmentos de esta especificación siguen idénticos.
4. Registra en el informe qué archivos planeas crear/modificar y por qué.
5. Si para cumplir una tarea necesitas violar ADR-005, detenerte y reportar el bloqueo. No reinterpretar la decisión por cuenta propia.

## Fase 1 — Worker experimental separado

1. Crear un proyecto Worker separado del Worker web actual. Nombre sugerido: `todotube-media-gateway-dev`; adaptar a convenciones existentes.
2. Usar Wrangler y Streams API según la versión instalada. No actualizar dependencias globales sin necesidad.
3. Definir el origen de fixture mediante configuración local segura; el destino no debe venir libremente del usuario.
4. Exponer una ruta de prueba estable, por ejemplo `GET|HEAD /media/test-video.mp4`.
5. Implementar GET/HEAD, Range, 206, 416, OPTIONS/CORS, streaming por chunks, cancelación y manejo de errores.
6. Mantener allowlist estricta de host y ruta. Deshabilitar credenciales. Validar redirecciones.
7. No usar `response.arrayBuffer()`, `response.blob()` ni `response.text()` para consumir el cuerpo multimedia completo.
8. No crear un endpoint `/proxy?url=` genérico.
9. No añadir lógica de YouTube, Googlevideo, InnerTube, BotGuard, PoToken o SABR al Worker.

## Fase 2 — Fixture y cliente de prueba

1. Añadir un fixture pequeño de vídeo propio o generar uno local para pruebas. Si el repo no puede alojar binarios, documentar cómo generar el fixture con una herramienta ya disponible y no descargar contenido protegido.
2. Crear una página de prueba separada de la aplicación de producción.
3. Reproducir mediante HTML5 y comprobar seek. Si resulta viable, crear una prueba separada con Shaka, sin cambiar el reproductor de producción.
4. La página de prueba debe señalar claramente que es un entorno experimental.

## Fase 3 — Pruebas automatizadas

Implementar los casos de `test-plan.md`. Cubrir como mínimo:

- GET completo y hash de bytes.
- HEAD sin cuerpo.
- Range inicial, intermedio y final.
- Range inválido/insatisfacible.
- OPTIONS y CORS permitido/no permitido.
- destino no permitido, path traversal, localhost, IP privada y metadata endpoints.
- redirección a destino no permitido.
- cancelación del stream.
- respuesta upstream 4xx/5xx y upstream sin cabeceras esperadas.
- evidencia de entrega incremental de chunks.

No simular como aprobada una prueba de streaming si el test consume el cuerpo entero antes de comprobar el primer chunk.

## Fase 4 — Regresión del producto actual

Ejecutar los comandos que realmente existan en el repo:

- build de web;
- TypeScript/typecheck;
- suite Playwright existente;
- tests nuevos del Worker.

No modificar snapshots ni debilitar tests para hacerlos pasar. Si el entorno no permite un test, registrar el error y el motivo exacto.

## Fase 5 — Informe y cierre

Crear `specs/008-gateway-multimedia/results.md` con:

1. resumen de lo implementado;
2. archivos creados/modificados;
3. comandos ejecutados y resultados;
4. matriz CA-01…CA-13: aprobado/fallido/bloqueado/no ejecutado;
5. medidas de latencia/throughput solo si se midieron;
6. límites de Workers identificados con enlaces a documentación oficial y fecha;
7. seguridad: SSRF, CORS, allowlist, redirecciones, abuso;
8. costes: qué se pudo medir y qué no; no inventar estimaciones;
9. pruebas manuales pendientes;
10. recomendación: continuar, rediseñar o detener.

## Restricciones de cambios

- No editar ADR-005.
- No editar `apps/web/src/components/PlayerHost.tsx`, `OwnPlayer.tsx`, `OfficialPlayer.tsx`, `TodoTubePlayer.ts` ni `ShakaPlayerAdapter.ts` para esta PoC.
- No cambiar `apps/web/wrangler.toml`, rutas, DNS, variables o secretos de producción.
- No quitar, debilitar ni cambiar la extensión Puente.
- No cambiar el comportamiento de fallback.
- No usar streams de YouTube como fixtures.
- No hacer deploy.
- No añadir credenciales ni tokens a archivos versionados.

## Resultado esperado

Un Worker experimental separado, tests automatizados reproducibles, fixture HTML5 (y Shaka si viable), y un informe honesto. La PoC solo demuestra la capacidad de transporte con un origen controlado; no demuestra compatibilidad con YouTube ni autoriza una arquitectura de extracción en servidor.


---

# Plan de pruebas · Gateway multimedia PoC

## Principios

- Ejecutar en local con Wrangler y fixtures propios.
- Ninguna prueba debe consultar YouTube, Googlevideo, InnerTube ni BotGuard.
- Cada caso debe registrar status, cabeceras relevantes, bytes recibidos y resultado.
- No marcar como aprobado un caso que no se ejecutó.
- Probar en navegador real al menos una vez para validar CORS y seek.

## Matriz de pruebas

| ID | Caso | Resultado esperado |
|---|---|---|
| GW-001 | GET completo | 200; bytes y hash iguales al fixture de origen |
| GW-002 | HEAD | 200; cabeceras de representación; cuerpo vacío |
| GW-003 | Range `bytes=0-1023` | 206; Content-Range exacto; 1024 bytes |
| GW-004 | Range intermedio | 206; devuelve exactamente el intervalo pedido |
| GW-005 | Range abierto `bytes=N-` | 206 con longitud restante correcta |
| GW-006 | Range fuera de tamaño | 416 y `Content-Range: bytes */<length>` |
| GW-007 | Range malformado/múltiple | Rechazo seguro o comportamiento documentado; nunca devolver bytes incorrectos |
| GW-008 | OPTIONS desde origen permitido | 204/200 con métodos y cabeceras estrictamente necesarios |
| GW-009 | OPTIONS desde origen no permitido | Sin `Access-Control-Allow-Origin` autorizante |
| GW-010 | GET con origen no permitido | Política explícita; no reflejar el origen arbitrariamente |
| GW-011 | Host destino fuera de allowlist | 400/403; no se hace fetch |
| GW-012 | localhost, loopback, RFC1918, link-local y metadata IP | Rechazo; no se hace fetch |
| GW-013 | path traversal y encoding ambiguo | Rechazo |
| GW-014 | redirección del origen a host no permitido | Rechazo; no seguir redirección abierta |
| GW-015 | upstream 404/500 | Propagar estado adecuado; no devolver 200 |
| GW-016 | upstream sin Content-Length | Streaming correcto sin inventar longitud |
| GW-017 | cancelación del cliente | Se aborta upstream cuando sea posible; medir/registrar comportamiento |
| GW-018 | streaming incremental | Primer chunk llega antes de consumir el cuerpo completo en origen |
| GW-019 | archivo de vídeo HTML5 | Reproduce, pausa, seek, volumen y finalización |
| GW-020 | Shaka aislado (si viable) | Carga el fixture y puede hacer seek sin errores de red |
| GW-021 | regresión web | Build, typecheck y Playwright existentes siguen pasando |
| GW-022 | aislamiento de producción | Diff confirma que el Worker web, sus rutas y el Puente no cambiaron |

## Validaciones de protocolo

### Range

- Enviar Range al origen solo después de validarlo.
- Si upstream devuelve 206, preservar Content-Range, Content-Length, Content-Type y Accept-Ranges coherentes.
- Si upstream ignora Range y devuelve 200, no fingir una respuesta 206.
- No construir un 206 incorrecto cortando un cuerpo completo almacenado en memoria.
- Validar que el rango solicitado corresponde al tamaño del fixture.

### CORS

- Permitir solo el origen de desarrollo definido en configuración.
- No usar `Access-Control-Allow-Origin: *` junto con credenciales.
- Exponer `Accept-Ranges`, `Content-Range`, `Content-Length` y `Content-Type` solo si el cliente los necesita.
- Permitir únicamente headers/métodos requeridos por las pruebas.
- Recordar: CORS no es control de acceso ni protección contra abuso.

### Streaming y cancelación

- Utilizar `Response.body` como ReadableStream y reenviar el stream sin materializar el archivo completo.
- Propagar AbortSignal si la API de fetch/Worker lo permite.
- Testear backpressure y cancelación; documentar limitaciones del runtime.
- No añadir caché hasta demostrar que respeta Range, validators y privacidad.

## Pruebas manuales

En Chromium y Firefox:

1. Abrir la página de fixture local.
2. Verificar que el vídeo comienza antes de descargarlo completo.
3. Saltar a un punto cercano al final.
4. Comprobar que se realiza una solicitud Range.
5. Revisar Network: origen de la petición, status 206, Content-Range y ausencia de CORS errors.
6. Repetir con DevTools throttling.
7. Cancelar/cerrar el reproductor y revisar que no continúan solicitudes innecesarias.

## No cubierto por esta PoC

- Compatibilidad con URLs de Googlevideo.
- Firma/descifrado de URL.
- PoToken/BotGuard.
- UMP/SABR real de YouTube.
- Directos y DVR de YouTube.
- Viabilidad contractual de retransmitir contenido de YouTube desde Cloudflare.
- Coste de producción a escala.

Estos puntos requieren otra fase y otra aprobación. No inferir que funcionan a partir de los resultados del fixture.


---

# Referencias técnicas oficiales

Fuentes oficiales de Cloudflare consultadas el 7 de noviembre de 2026. El agente debe verificar su vigencia y los límites del plan activo al implementar.

1. **Streams API:** https://developers.cloudflare.com/workers/runtime-apis/streams/  
   Describe `ReadableStream`, `TransformStream` y el envío de respuestas progresivas sin materializar todo el cuerpo en memoria. La documentación consultada señala límite de memoria de 128 MB para Workers.
2. **Workers Limits:** https://developers.cloudflare.com/workers/platform/limits/  
   Límites por plan, CPU, subrequests, conexiones salientes, memoria y request/response. La página consultada mostraba actualización de octubre de 2026; los valores pueden cambiar.
3. **Best Practices:** https://developers.cloudflare.com/workers/best-practices/workers-best-practices/  
   Recomienda streaming de cuerpos grandes y evitar `response.text()` / `arrayBuffer()` para cargas grandes.
4. **Response API:** https://developers.cloudflare.com/workers/runtime-apis/response/  
   Semántica de `Response`, cuerpo `ReadableStream`, cabeceras y `Content-Length`.
5. **Pricing:** https://developers.cloudflare.com/workers/platform/pricing/  
   Revisar solicitudes, CPU y cargos del plan. No deducir el coste total del servicio solo a partir del precio de invocación.
6. **Piped Proxy:** https://github.com/TeamPiped/piped-proxy  
   Proyecto de referencia para estudiar una arquitectura de proxy multimedia. No es evidencia de compatibilidad de YouTube con Cloudflare Workers ni autorización para reutilizar su código sin revisar licencia.
